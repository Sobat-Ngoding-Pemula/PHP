<?php

	$sego = 'INI ADALAH NASI';
	ECHO 'INI ADALAH BUDI <br> <hr>';
	ECHO $sego;

?>