<?php
	//ini untuk  mencetak tulisan
	echo "hello world! <br>";
	
	//ini untuk mencetak angka
	echo "aku adalah PHP!<br>";


	$nilai1 = 42342343;
	$nilai2 = 324234;
	$jumlah = $nilai1 * $nilai2;
	echo 'hasil dari 42342343 x 324234 adalah = '.$jumlah;
?>